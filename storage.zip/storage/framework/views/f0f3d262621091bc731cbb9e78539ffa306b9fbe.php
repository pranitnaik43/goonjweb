<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>

    <form action ="<?php echo e(action('StorageController@add')); ?>", method = 'POST' style="width:100%">
            <?php echo csrf_field(); ?>
    

    <div class="d-flex justify-content-center">
    
    <table class="table table-striped table-hover" style="width:60%">
        <thead>
        <tr>
            <th>Material</th>
            <th>Quantity</th>
            <th>Measure</th>
        </tr>
        </thead>
        <tbody  id="myTable">
            <tr>
                <td>
                <input type="text" id="name" name="name" autofocus><br>
                <?php if($errors->has('name')): ?>
                    <span class="help-block" style="color:red">
                        <?php echo e($errors->first('name')); ?>*
                    </span>
                <?php endif; ?>
                </td>
                <td>
                <input type="text" id="quantity" name="quantity"><br>
                <?php if($errors->has('quantity')): ?>
                    <span class="help-block" style="color:red"> 
                        <?php echo e($errors->first('quantity')); ?>*
                    </span>
                <?php endif; ?>
                </td>
                <td>
                <input type="text" id="measure" name="measure"><br>
                <?php if($errors->has('measure')): ?>
                    <span class="help-block" style="color:red">
                        <?php echo e($errors->first('measure')); ?>*
                    </span>
                <?php endif; ?>
                </td>
                <td><button class = 'btn btn-primary'>Add</button></td>
                    
                
            </tr>
        
        <?php $__currentLoopData = array_reverse($data[0]['material']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <tr>
            <td><?php echo e($mat['name']); ?></td>
            <td><?php echo e($mat['quantity']); ?></td>
            <td><?php echo e($mat['measure']); ?></td>
            <td><a href="/editStorage/<?php echo e($mat['id']); ?>" class = 'btn btn-primary'>Edit</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </tbody>
    </table>
    
    </div>
    </form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.storageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>