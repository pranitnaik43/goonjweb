<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                     
                     
                    
                    <form method="POST" action="<?php echo e(route('register')); ?>" id="form1">
                         
                        
                        
                        <?php echo csrf_field(); ?>

        <div class="row">
                <div class="col-sm-3">
                    <div class="form-group">
                        <label>First Name:</label><span style="color: red">*</span>
                        <?php echo e(Form::text('first_name','', ['class' => 'form-control', 'placeholder' => 'First' , ($errors->has('first_name')) ? 'autofocus' : ''])); ?>

                        <?php if($errors->has('first_name')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('first_name')); ?>*
                                </span>
                            <?php endif; ?>
                    </div>             
                </div>

                <div class="col-sm-3">
                        <div class="form-group">
                            <label>Middle Name:</label>
                            <?php echo e(Form::text('middle_name', '', ['class' => 'form-control', 'placeholder' => 'Middle Name', ($errors->has('middle_name')) ? 'autofocus' : ''])); ?>

                            <?php if($errors->has('middle_name')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('middle_name')); ?>*
                                </span>
                            <?php endif; ?>
                        </div>             
                </div>

                <div class="col-sm-3">
                        <div class="form-group">
                            <label>Last Name:</label><span style="color: red">*</span>
                            <?php echo e(Form::text('last_name', '', ['class' => 'form-control', 'placeholder' => 'Last Name', ($errors->has('last_name')) ? 'autofocus' : ''])); ?>

                            <?php if($errors->has('last_name')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('last_name')); ?>*
                                </span>
                            <?php endif; ?>
                        </div>             
                </div>
        </div>

        
        <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                    <label>Email ID:</label><span style="color: red">*</span>
                    <?php echo e(Form::text('email', '', ['class' => 'form-control', 'placeholder' => 'Email ID', ($errors->has('email')) ? 'autofocus' : ''])); ?>

                    <?php if($errors->has('email')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('email')); ?>*
                                </span>
                            <?php endif; ?>
                </div>             
            </div>

            <div class="col-sm-3">
                <div class="form-group">
                    <label>Contact No:</label><span style="color: red">*</span>
                    <?php echo e(Form::text('contact_no', '', ['class' => 'form-control', 'placeholder' => 'Contact No', ($errors->has('contact_no')) ? 'autofocus' : ''])); ?>

                    <?php if($errors->has('contact_no')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('contact_no')); ?>*
                                </span>
                            <?php endif; ?>
                </div>             
            </div>

            <div class="col-sm-4">
                <div class="form-group">
                    <label>Secondary Contact No:</label>
                    <?php echo e(Form::text('alternative_contact_no', '', ['class' => 'form-control', 'placeholder' => 'Alternative Contact No', ($errors->has('alternative_contact_no')) ? 'autofocus' : ''])); ?>

                    <?php if($errors->has('alternative_contact_no')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('alternative_contact_no')); ?>*
                                </span>
                            <?php endif; ?>
                </div>             
            </div>

        </div>
            
            

        <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Address Line 1:</label><span style="color: red">*</span>
                        <?php echo e(Form::textarea('address_line_1', '', ['size' => '70x1', 'class' => 'form-control', 'placeholder' => 'Address Line 1', ($errors->has('address_line_1')) ? 'autofocus' : ''])); ?>

                        <?php if($errors->has('address_line_1')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('address_line_1')); ?>*
                                </span>
                            <?php endif; ?>
                    </div>             
                </div>

                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Address Line 2:</label><span style="color: red">*</span>
                        <?php echo e(Form::textarea('address_line_2', '', ['size' => '70x1', 'class' => 'form-control', 'placeholder' => 'Address Line 2', ($errors->has('address_line_2')) ? 'autofocus' : ''])); ?>

                        <?php if($errors->has('address_line_2')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('address_line_2')); ?>*
                                </span>
                            <?php endif; ?>
                    </div>             
                </div>

                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Address Line 3:</label><span style="color: red">*</span>
                        <?php echo e(Form::textarea('address_line_3', '', ['size' => '70x1', 'class' => 'form-control', 'placeholder' => 'Address Line 3', ($errors->has('address_line_3')) ? 'autofocus' : ''])); ?>

                        <?php if($errors->has('address_line_3')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('address_line_3')); ?>*
                                </span>
                            <?php endif; ?>
                    </div>             
                </div>
        </div>


            <div class="row">
                <div class="col-sm-3">
                    <div class="form-group">
                            <label>City:</label><span style="color: red">*</span>
                            <?php echo e(Form::text('city', '', ['class' => 'form-control', 'placeholder' => 'City', ($errors->has('city')) ? 'autofocus' : ''])); ?>

                            <?php if($errors->has('city')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('city')); ?>*
                                </span>
                            <?php endif; ?>
                    </div>             
                </div>
                
                
                
                <div class="col-sm-3">
                    <div class="form-group">
                            <label>State:</label><span style="color: red">*</span>
                            <?php echo e(Form::text('state', '', ['class' => 'form-control', 'placeholder' => 'State', ($errors->has('state')) ? 'autofocus' : ''])); ?>

                            <?php if($errors->has('state')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('state')); ?>*
                                </span>
                            <?php endif; ?>
                    </div>             
                </div>

                <div class="col-sm-3">
                    <div class="form-group">
                            <label>Country:</label><span style="color: red">*</span>
                            <?php echo e(Form::text('country', '', ['class' => 'form-control', 'placeholder' => 'Country', ($errors->has('country')) ? 'autofocus' : ''])); ?>

                            <?php if($errors->has('country')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('country')); ?>*
                                </span>
                            <?php endif; ?>
                    </div>             
                </div>

            </div>

        <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Postal Code:</label><span style="color: red">*</span>
                        <?php echo e(Form::text('postal_code', '', ['class' => 'form-control', 'placeholder' => 'Postal Code', ($errors->has('postal_code')) ? 'autofocus' : ''])); ?>

                        <?php if($errors->has('postal_code')): ?>
                                <span class="help-block" style="color:red">
                                    <?php echo e($errors->first('postal_code')); ?>*
                                </span>
                            <?php endif; ?>
                    </div>             
                </div>

                <div class="col-sm-3">
                    <div class="form-group">
                        <label>Type Of Role:</label><span style="color: red">*</span>
                        <br>
                        <?php echo e(Form::select('type_of_role', array('3' => 'User', '4' => 'Volunteer', '5'=>'Shipper', '6' =>'Storage Centre'), '', ['class'=> 'form-control'])); ?>

                        <?php if($errors->has('type_of_role')): ?>
                                    <span class="help-block" style="color:red">
                                        <?php echo e($errors->first('type_of_role')); ?>*
                                    </span>
                                <?php endif; ?>
                        <br>
                    </div>             
                </div>
        </div>

        <div class="form-group row">
            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

            <div class="col-md-6">
                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

            <div class="col-md-6">
                <input id="password-confirm" type="password" class="form-control<?php echo e($errors->has('password-confirm') ? ' is-invalid' : ''); ?>" name="password_confirmation" required>
                <?php if($errors->has('password-confirm')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password-confirm')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div> 

                
                
                <button type="submit" class="btn btn-primary">
                Submit
                </button>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>