<!DOCTYPE html>
<html lang="en">
<head>
  <title>Goonj</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="/dashboard">Dashboard</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="/admin/home">Home</a></li>
      <li><a href="/admin/disaster">Disasters</a></li>
      <li><a href="/admin/approve">Approve Unverified Users</a></li>
      <li><a href="/admin/ReliefCentre">Set Up Relief Centre</a></li>
      <li><a href="/admin/onsiteTeam">Create Onsite Team</a></li>
      <li><a href="/admin/onsite">View Onsite Orders</a></li>
      <li><a href="/admin/storagecentre">Storage Centres</a></li>
    </ul>
  </div>
</nav>
  

  





<body>
  <div class="well well-lg">
      <h1 style= "color: SteelBlue"><u>Unapproved Users</u></h1>
     <label for="usr" style= "color: SteelBlue" input align="right">Unapproved Users Count:</label>
  <input type="text" class="" id="usr" input align="right" value="<?php echo e(count($awaited_users)); ?>" readonly>

  <table class="table table-striped table-bordered table-hover table-condensed">
      <thead style= "color: SteelBlue">
          <tr style="color: blue-grey lighten-4">
             <th>Waiting_list_no</th>
             <th>First Name</th>
             <th>Last Name</th>
             <th>Contact No</th>
             <th>Email</th>
         </tr>
         
     </thead>
     <?php if(count($awaited_users)>0): ?>
     <?php $__currentLoopData = $awaited_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $awaited_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <tbody>
          <!--<table class="table table-striped table-bordered table-hover table-condensed">-->
          
              <tr>    
              
              <td><h6><?php echo e($awaited_user->waiting_list_no); ?></h6></td>
              <td><h6><?php echo e($awaited_user->first_name); ?></h6></td>
              <td><h6><?php echo e($awaited_user->last_name); ?></h6></td>
              <td><h6><?php echo e($awaited_user->contact_no); ?></h6></td>
              <td><h6><?php echo e($awaited_user->email); ?></h6></td>
              <td><h6><a href="/admin/approve/<?php echo e($awaited_user->waiting_list_no); ?>"><button type="button">View</a></h6></td>
              
              
              </tr>
          
          </tbody>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <?php echo e($awaited_users->links()); ?>

  <?php else: ?>
  <p>No Unapproved Users</p>
  <?php endif; ?>
      </div>
  </body>


</body>
</html>


    