<?php $__env->startSection('content'); ?>
    <?php echo e(Form::open(['action' => 'AdminOfficeController@approveQuotation'])); ?>

    <div class="d-flex justify-content-center" style="border:black">            
    <table class="table table-striped table-hover" style="width:60%">
        <thead>
        <tr>
            <th>Team</th>
            <th>Operation</th>
        </tr>
        </thead>
        <tbody id="myTable">
        <?php $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quotation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <tr>
            <td><?php echo e($quotation['team_id']); ?></td>
            <td><a href="/viewQuotation/<?php echo e($quotation['quotation_id']); ?>" class="btn btn-primary">View<a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    <div class="d-flex justify-content-center">         
        <button class = 'btn btn-primary'>Submit</button>
    </div>
    <?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>