<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    <?php echo e(Form::open(array('action' => array('StorageController@edit', $id_data['id'])))); ?>

    <?php echo csrf_field(); ?>
    <div class="d-flex justify-content-center" style="border:black">
    <table class="table table-striped table-hover" style="width:60%">
        <thead>
        <tr>
            <th>Material</th>
            <th>Quantity</th>
            <th>Measure</th>
        </tr>
        </thead>
        <tbody  id="myTable">

        <?php $__currentLoopData = array_reverse($data[0]['material']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <?php if($mat['id'] == $id_data['id']): ?>
            <tr>
                <td>
                <input type="text" id="name" name="name" value="<?php echo e($mat['name']); ?>"><br>
                <?php if($errors->has('name')): ?>
                    <span class="help-block" style="color:red">
                        <?php echo e($errors->first('name')); ?>*
                    </span>
                <?php endif; ?>
                </td>
                <td>
                <input type="text" id="quantity" name="quantity" value="<?php echo e($mat['quantity']); ?>"  autofocus><br>
                <?php if($errors->has('quantity')): ?>
                    <span class="help-block" style="color:red">
                        <?php echo e($errors->first('quantity')); ?>*
                    </span>
                <?php endif; ?>
                </td>
                <td>
                <input type="text" id="measure" name="measure" value="<?php echo e($mat['measure']); ?>"><br>
                <?php if($errors->has('measure')): ?>
                    <span class="help-block" style="color:red">
                        <?php echo e($errors->first('measure')); ?>*
                    </span>
                <?php endif; ?>
                </td>
                <td><button class = 'btn btn-primary'>Submit</button></td>
            </tr>
            <?php else: ?>
                <tr>
                    <td><?php echo e($mat['name']); ?></td>
                    <td><?php echo e($mat['quantity']); ?></td>
                    <td><?php echo e($mat['measure']); ?></td>
                    
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </tbody>
    </table>
    </div>
    <?php echo e(Form::close()); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.storageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>