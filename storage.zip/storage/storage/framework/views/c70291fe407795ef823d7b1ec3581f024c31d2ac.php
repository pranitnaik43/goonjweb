<html>
    <body>
        <p>
            print:<?php echo e($data); ?>

        </p>
    </body>
</html>