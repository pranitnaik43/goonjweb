<?php $__env->startSection('content'); ?>
    
    <div class="d-flex justify-content-center" style="border:black">            
    <table class="table table-striped table-hover" style="width:60%">
        <thead>
        <tr>
            <th>Material</th>
            <th>Quantity</th>
            <th>Measure</th>
        </tr>
        </thead>
        <tbody id="myTable">
        <?php $__currentLoopData = array_reverse($data[0]['material']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <tr>
            <td><?php echo e($mat['name']); ?></td>
            <td><?php echo e($mat['quantity']); ?></td>
            <td><?php echo e($mat['measure']); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    

    

    
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.storageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>