<?php $__env->startSection('content'); ?>
    <H3>Team ID:<small><?php echo e($quotation['team_id']); ?></small></H3>
    <div class="d-flex justify-content-center" style="border:black">            
    <table class="table table-striped table-hover" style="width:60%">
    
        <thead>
        <tr>
            <th>Material</th>
            <th>Quantity</th>
            <th>Measure</th>
        </tr>
        </thead>
        <tbody id="myTable">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <tr>
            <td><?php echo e($mat['name']); ?></td>
            <td><?php echo e($mat['quantity']); ?></td>
            <td><?php echo e($mat['measure']); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    <div class="d-flex justify-content-center">
        <a href="/editQuotation" class="btn btn-primary">Add/Edit Material</a>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>